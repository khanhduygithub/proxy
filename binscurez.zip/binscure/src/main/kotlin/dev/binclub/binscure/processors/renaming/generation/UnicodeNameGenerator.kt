package dev.binclub.binscure.processors.renaming.generation

import dev.binclub.binscure.CObfuscator
import dev.binclub.binscure.classpath.ClassSources
import org.objectweb.asm.tree.ClassNode

/**
 * UnicodeNameGenerator: generates names using Unicode chars that look like Latin letters
 * and optionally shadow Java keywords to maximize decompiler confusion.
 */
class UnicodeNameGenerator(prefix: String = "") : NameGenerator(prefix) {

    companion object {
        // Unicode chars visually similar to ASCII but different codepoints
        // These are valid Java identifiers but break most decompilers/IDEs
        private val UNICODE_CHARSET = charArrayOf(
            '\u0049', '\u006C', // I, l (classic confusion)
            '\u0406', '\u04C0', // І, Ӏ (Cyrillic)
            '\u0399', '\u03B9', // Ι, ι (Greek Iota)
            '\u2160', '\u2161', '\u2162', // Ⅰ, Ⅱ, Ⅲ (Roman numerals)
            '\u01C0', '\u01C1', // ǀ, ǁ (Latin letter pipe)
            '\u0030', '\u004F', '\u006F', // 0, O, o (zero/O confusion)
            '\u0041', '\u0061', // A, a
            '\u13A0', '\u13A1', // Ꭰ, Ꭱ (Cherokee)
            '\uFF29', '\uFF4C', // Ａ,ｌ (fullwidth)
        )

        // Java keywords used as method/field names (valid in bytecode but not source)
        private val KEYWORD_NAMES = arrayOf(
            "if", "for", "do", "while", "return", "class", "void",
            "int", "long", "float", "double", "boolean", "byte",
            "new", "this", "super", "null", "true", "false",
            "try", "catch", "throw", "throws", "finally",
            "static", "final", "abstract", "native", "public",
            "private", "protected", "import", "package", "extends",
            "implements", "interface", "enum", "switch", "case",
            "default", "break", "continue", "instanceof", "synchronized"
        )

        private var keywordIdx = 0

        fun nextKeywordName(): String {
            val name = KEYWORD_NAMES[keywordIdx % KEYWORD_NAMES.size]
            keywordIdx++
            return name
        }

        fun nextUnicodeName(length: Int = 8): String {
            return (0 until length).map {
                UNICODE_CHARSET[CObfuscator.random.nextInt(UNICODE_CHARSET.size)]
            }.joinToString("")
        }

        fun mixedName(): String {
            // Mix keywords with unicode for maximum confusion
            return nextKeywordName() + nextUnicodeName(4)
        }
    }

    private var useKeywords = false

    override fun uniqueRandomString(): String {
        return when (CObfuscator.random.nextInt(3)) {
            0 -> nextUnicodeName(CObfuscator.random.nextInt(6) + 4)
            1 -> nextKeywordName()
            else -> mixedName()
        }
    }

    fun uniqueUntakenClassName(sources: ClassSources): String {
        do {
            val name = prefix + nextUnicodeName(6)
            if (!sources.classes.containsKey(name) &&
                !sources.classPath.containsKey(name) &&
                !sources.passThrough.containsKey("$name.class")
            ) return name
        } while (true)
    }
}
